import trimesh

cube = trimesh.creation.box(extents=(2.0, 2.0, 2.0))
cube.export("sample_cube.stl")
print("Created sample_cube.stl (2 x 2 x 2 model units).")
