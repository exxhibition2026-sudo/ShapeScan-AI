from __future__ import annotations
import os

def answer_question(question: str, analysis: dict | None, api_key: str | None = None) -> str:
    key = api_key or os.getenv("OPENAI_API_KEY")
    if key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=key)
            response = client.chat.completions.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                temperature=0.3,
                messages=[
                    {"role": "system", "content":
                     "You are a friendly geometry tutor for school students. Explain step by step, "
                     "define variables, use correct units, and distinguish measured values from estimates. "
                     "Never invent dimensions. If data is missing, explain what is needed."},
                    {"role": "user", "content":
                     f"Current object analysis: {analysis or 'No object has been analyzed yet.'}\\n"
                     f"Student question: {question}"}
                ]
            )
            return response.choices[0].message.content or "I couldn't generate an answer."
        except Exception as exc:
            return f"AI tutor unavailable ({exc}).\\n\\n{local_answer(question, analysis)}"
    return local_answer(question, analysis)

def local_answer(question: str, analysis: dict | None) -> str:
    q = question.lower()
    if not analysis:
        return ("Upload a photo or a 3D model first. I can then explain the detected shape. "
                "For a photo, real-world size needs a ruler/reference, depth data, or multiple views.")
    if analysis.get("kind") == "3D model":
        d = analysis.get("dimensions", {})
        if any(k in q for k in ("dimension", "size", "length", "width", "height")):
            return (f"The model's axis-aligned bounding-box extents are X={d.get('X')}, "
                    f"Y={d.get('Y')}, Z={d.get('Z')} {analysis.get('units','model units')}. "
                    "These are coordinate extents, not necessarily the object's dimensions along its own rotated axes.")
        if "volume" in q:
            v = analysis.get("mesh_volume")
            if v is None:
                return "A reliable mesh volume is unavailable because the mesh is not watertight. Repair the mesh or use a closed solid."
            return f"The calculated mesh volume is {v} cubic model units. Confirm the model's unit convention before interpreting it physically."
        if "surface" in q or "area" in q:
            return f"The mesh surface area is {analysis.get('surface_area')} square model units."
        return (f"The mesh is described as {analysis.get('shape_estimate')}. It has "
                f"{analysis.get('vertices')} vertices and {analysis.get('triangles')} triangular faces.")
    if "volume" in q or "surface area" in q:
        return ("To calculate volume or surface area, we need reliable dimensions. "
                "A single uncalibrated photograph does not provide physical scale. "
                "Upload a 3D model or include a known-size ruler/reference in the image.")
    return ("I can help explain faces, edges, vertices, symmetry, volume and surface area. "
            "Ask about a specific property, or configure an API key for conversational AI tutoring.")
