from __future__ import annotations
import base64
import json
import mimetypes
import os
from pathlib import Path

def analyze_image_with_ai(path: str, api_key: str | None = None) -> dict:
    """Use a vision-capable OpenAI model to describe a 2D photo.

    A single ordinary photo cannot provide reliable real-world dimensions without
    calibration, depth, or multiple views. The prompt explicitly prevents guessing.
    """
    key = api_key or os.getenv("OPENAI_API_KEY")
    if not key:
        raise RuntimeError("No API key configured. Add OPENAI_API_KEY to your environment to enable AI image recognition.")
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("Install dependencies first: pip install -r requirements.txt") from exc

    path_obj = Path(path)
    mime = mimetypes.guess_type(path_obj.name)[0] or "image/jpeg"
    if mime not in {"image/jpeg", "image/png", "image/webp", "image/gif"}:
        mime = "image/jpeg"
    encoded = base64.b64encode(path_obj.read_bytes()).decode("utf-8")
    data_url = f"data:{mime};base64,{encoded}"

    client = OpenAI(api_key=key)
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    response = client.chat.completions.create(
        model=model,
        temperature=0.1,
        response_format={"type": "json_object"},
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a careful educational geometry vision assistant. "
                    "Analyze only visible evidence. Never invent real-world measurements. "
                    "A single uncalibrated photo has no dependable physical scale. "
                    "Return JSON with keys: detected_objects (array of objects with "
                    "shape, confidence (0-1), visual_evidence, visible_features), "
                    "dimension_status, dimensions, measurement_requirements, "
                    "educational_note. Set dimension_status to 'not measurable from "
                    "this photo alone' unless a clearly readable scale/reference is "
                    "visible and can be calibrated. If dimensions are uncertain, use null."
                )
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Identify visible 3D geometric objects for a student. Explain the evidence and measurement limitations."},
                    {"type": "image_url", "image_url": {"url": data_url, "detail": "high"}}
                ]
            }
        ]
    )
    content = response.choices[0].message.content or "{}"
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return {"raw_analysis": content, "dimension_status": "not measurable from this photo alone"}
