from __future__ import annotations
import math
import trimesh
import numpy as np

SUPPORTED_3D = {".obj", ".stl", ".ply", ".glb", ".gltf", ".off", ".3mf"}

def _round(value, digits=3):
    try:
        return round(float(value), digits)
    except Exception:
        return None

def analyze_3d(path: str) -> dict:
    """Load a mesh and compute geometric measurements in the file's coordinate units."""
    loaded = trimesh.load(path, force="scene")
    if isinstance(loaded, trimesh.Scene):
        meshes = [g for g in loaded.geometry.values() if isinstance(g, trimesh.Trimesh) and len(g.vertices)]
        if not meshes:
            raise ValueError("No polygon mesh was found in this 3D file.")
        mesh = trimesh.util.concatenate(meshes)
    elif isinstance(loaded, trimesh.Trimesh):
        mesh = loaded
    else:
        raise ValueError("The file does not contain a supported triangular mesh.")

    if len(mesh.vertices) == 0 or len(mesh.faces) == 0:
        raise ValueError("The 3D model is empty.")

    extents = np.asarray(mesh.bounds[1] - mesh.bounds[0], dtype=float)
    ordered = sorted(extents.tolist(), reverse=True)
    x, y, z = [float(v) for v in extents]
    positive = [v for v in extents if v > 1e-9]
    ratio = max(positive) / min(positive) if len(positive) >= 2 else 1.0

    if ratio < 1.08:
        shape = "approximately cube-like / equidimensional solid"
    elif min(positive) / max(positive) < 0.08:
        shape = "approximately flat or plate-like solid"
    elif abs(ordered[0] - ordered[1]) / max(ordered[0], 1e-9) < 0.12:
        shape = "approximately cylinder-like or prism-like (inspect the mesh)"
    else:
        shape = "irregular 3D solid / cuboid-like bounding shape"

    watertight = bool(mesh.is_watertight)
    volume = abs(float(mesh.volume)) if watertight else None
    area = float(mesh.area)
    return {
        "kind": "3D model",
        "shape_estimate": shape,
        "dimensions": {"X": _round(x), "Y": _round(y), "Z": _round(z)},
        "bounding_box_volume": _round(x * y * z),
        "surface_area": _round(area),
        "mesh_volume": _round(volume) if volume is not None else None,
        "watertight": watertight,
        "vertices": int(len(mesh.vertices)),
        "triangles": int(len(mesh.faces)),
        "units": "model units (the file may not specify whether these are mm, cm, or m)",
        "warning": "Dimensions are the axis-aligned bounding-box extents. Confirm the model's unit convention and orientation."
    }

def cube_metrics(side: float, unit: str = "cm") -> dict:
    return {
        "shape": "cube", "side": side, "unit": unit,
        "volume": side ** 3, "surface_area": 6 * side ** 2,
        "faces": 6, "edges": 12, "vertices": 8
    }
