from __future__ import annotations
import json
import os
import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QTextEdit, QFileDialog, QLineEdit, QMessageBox, QSplitter, QGroupBox
)

from .geometry import analyze_3d, SUPPORTED_3D
from .image_ai import analyze_image_with_ai
from .tutor import answer_question

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("3D Shape AI Tutor")
        self.resize(1120, 760)
        self.analysis = None
        self.current_image = None

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        header = QLabel("3D Shape Detection · Educational AI Tutor")
        header.setStyleSheet("font-size: 22px; font-weight: 700; padding: 8px;")
        root.addWidget(header)

        api_row = QHBoxLayout()
        api_row.addWidget(QLabel("OpenAI API key (optional):"))
        self.api_key = QLineEdit()
        self.api_key.setEchoMode(QLineEdit.Password)
        self.api_key.setPlaceholderText("Paste key for AI photo recognition and tutor chat; not saved")
        api_row.addWidget(self.api_key, 1)
        root.addLayout(api_row)

        controls = QHBoxLayout()
        self.image_btn = QPushButton("Upload photo (PNG/JPG)")
        self.image_btn.clicked.connect(self.open_image)
        self.model_btn = QPushButton("Upload 3D model (OBJ/STL/PLY/GLB)")
        self.model_btn.clicked.connect(self.open_model)
        controls.addWidget(self.image_btn)
        controls.addWidget(self.model_btn)
        root.addLayout(controls)

        splitter = QSplitter(Qt.Horizontal)
        root.addWidget(splitter, 1)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        self.preview = QLabel("Choose a photo or 3D model to begin")
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(360, 280)
        self.preview.setStyleSheet("background:#202733; color:#dbe4ee; border-radius:8px;")
        left_layout.addWidget(self.preview, 1)
        self.results = QTextEdit()
        self.results.setReadOnly(True)
        self.results.setPlaceholderText("Analysis results will appear here.")
        left_layout.addWidget(self.results, 1)
        splitter.addWidget(left)

        right = QGroupBox("Ask the geometry tutor")
        right_layout = QVBoxLayout(right)
        self.chat_log = QTextEdit()
        self.chat_log.setReadOnly(True)
        self.chat_log.setPlainText("Tutor: Upload an object, then ask me about its shape, dimensions, volume or surface area.")
        right_layout.addWidget(self.chat_log, 1)
        question_row = QHBoxLayout()
        self.question = QLineEdit()
        self.question.setPlaceholderText("Example: Explain how volume is calculated")
        self.question.returnPressed.connect(self.ask)
        self.ask_btn = QPushButton("Ask")
        self.ask_btn.clicked.connect(self.ask)
        question_row.addWidget(self.question, 1)
        question_row.addWidget(self.ask_btn)
        right_layout.addLayout(question_row)
        splitter.addWidget(right)
        splitter.setSizes([560, 560])

        self.statusBar().showMessage("Ready · 3D measurements use the model's coordinate units")

    def key(self):
        return self.api_key.text().strip() or None

    def open_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select a photo", "", "Images (*.png *.jpg *.jpeg *.webp *.bmp *.gif)"
        )
        if not path:
            return
        self.current_image = path
        pix = QPixmap(path)
        if not pix.isNull():
            self.preview.setPixmap(pix.scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.statusBar().showMessage("Analyzing photo…")
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            result = analyze_image_with_ai(path, self.key())
            self.analysis = result
            self.results.setPlainText(json.dumps(result, indent=2, ensure_ascii=False))
            self.statusBar().showMessage("Photo analysis complete")
        except Exception as exc:
            self.analysis = {
                "kind": "2D photo",
                "error": str(exc),
                "measurement_note": "A single uncalibrated photo cannot provide reliable real-world dimensions."
            }
            self.results.setPlainText(
                "PHOTO ANALYSIS\\n\\n" + str(exc) +
                "\\n\\nMeasurement note: one ordinary photo cannot establish physical size. "
                "Add a known reference scale, take multiple calibrated views, use depth data, "
                "or upload a 3D model.\\n\\nYou can still use the tutor for general geometry questions."
            )
            self.statusBar().showMessage("Photo loaded; AI analysis unavailable")
        finally:
            QApplication.restoreOverrideCursor()

    def open_model(self):
        filters = "3D models (*.obj *.stl *.ply *.glb *.gltf *.off *.3mf)"
        path, _ = QFileDialog.getOpenFileName(self, "Select a 3D model", "", filters)
        if not path:
            return
        self.statusBar().showMessage("Processing 3D mesh…")
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            result = analyze_3d(path)
            self.analysis = result
            self.results.setPlainText(json.dumps(result, indent=2, ensure_ascii=False))
            self.preview.setText(
                f"3D model analyzed\\n\\n{Path(path).name}\\n\\n"
                f"Estimated type: {result['shape_estimate']}\\n"
                f"X: {result['dimensions']['X']}\\nY: {result['dimensions']['Y']}\\nZ: {result['dimensions']['Z']}\\n\\n"
                "Measurements use model coordinate units."
            )
            self.statusBar().showMessage("3D model analysis complete")
        except Exception as exc:
            QMessageBox.critical(self, "3D model error", str(exc))
            self.statusBar().showMessage("Could not process model")
        finally:
            QApplication.restoreOverrideCursor()

    def ask(self):
        question = self.question.text().strip()
        if not question:
            return
        self.question.clear()
        self.chat_log.append(f"\\nYou: {question}")
        self.chat_log.append("Tutor: Thinking…")
        QApplication.processEvents()
        answer = answer_question(question, self.analysis, self.key())
        cursor = self.chat_log.textCursor()
        cursor.movePosition(cursor.End)
        cursor.select(cursor.LineUnderCursor)
        cursor.removeSelectedText()
        cursor.insertText("Tutor: " + answer)
        self.chat_log.setTextCursor(cursor)
        self.chat_log.ensureCursorVisible()

def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
