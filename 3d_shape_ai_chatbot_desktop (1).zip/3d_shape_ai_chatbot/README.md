# 3D Shape AI Tutor (Desktop)

A Python desktop starter application for educational geometry. It accepts both ordinary photos and 3D mesh files.

## What works in this starter

- Desktop GUI built with PySide6.
- 3D model analysis for OBJ, STL, PLY, GLB, GLTF, OFF and 3MF using `trimesh`.
- Calculates axis-aligned X/Y/Z extents, mesh surface area, and volume when the mesh is watertight.
- Optional OpenAI vision analysis for photos.
- Optional AI tutoring chat; without an API key, a small offline educational fallback is available.
- Clearly distinguishes exact mesh-derived measurements from photo estimates.

## Important measurement limitation

A single ordinary 2D photograph does not contain enough information to recover reliable real-world dimensions. Perspective, camera distance, lens distortion and unknown scale make physical size ambiguous. For photos, use a known-size calibration marker/ruler, calibrated multi-view photogrammetry, a depth camera, or a 3D scan. This starter's photo mode identifies and describes shapes with a vision model; it does not pretend to measure physical dimensions from an uncalibrated image.

3D mesh dimensions are reported in the coordinate units stored in the file. STL files commonly have no unit metadata, so the application cannot know whether a coordinate represents millimetres, centimetres or metres. Confirm units before using the values in class.

## Requirements

- Windows 10/11, macOS, or Linux
- Python 3.10+
- Internet connection and an OpenAI API key only for AI photo recognition and cloud tutor chat

## Install and run (Windows)

1. Install Python 3.10 or newer from https://www.python.org/downloads/
2. Extract this ZIP to a folder.
3. Double-click `run_windows.bat`, or open PowerShell in this folder and run:

```powershell
python -m venv .venv
.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m app.main
```

## Install and run (macOS/Linux)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m app.main
```

## Enable AI vision and chat

1. Create an API key in your OpenAI developer account.
2. Start the app and paste the key into the password field.
3. The key is held only in the running app's memory; this starter does not save it.
4. The app sends the selected photo and chat question to the configured OpenAI model. Do not upload private or sensitive images.

Alternatively set environment variables before launch:

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="your-key"
$env:OPENAI_MODEL="gpt-4o-mini"
python -m app.main
```

macOS/Linux:
```bash
export OPENAI_API_KEY="your-key"
export OPENAI_MODEL="gpt-4o-mini"
python -m app.main
```

API usage may incur charges. Check your provider's current pricing and usage limits.

## Supported 3D input formats

`.obj`, `.stl`, `.ply`, `.glb`, `.gltf`, `.off`, `.3mf`

## Test with a sample cube

Generate a 2 cm cube mesh using the included script:

```bash
python create_sample_cube.py
```

Then use Upload 3D model and select `sample_cube.stl`. The app should report dimensions close to 2 x 2 x 2 model units, surface area close to 24 square units and volume close to 8 cubic units (assuming a watertight mesh).

## Project structure

```text
3d_shape_ai_chatbot/
├── app/
│   ├── main.py
│   ├── geometry.py
│   ├── image_ai.py
│   └── tutor.py
├── requirements.txt
├── .env.example
├── create_sample_cube.py
├── run_windows.bat
└── run_mac_linux.sh
```

## Recommended next development milestones

1. Add a calibrated photo workflow: user marks a reference ruler/marker, then the system estimates image scale and measures planar visible dimensions.
2. Add multi-view photogrammetry (for example COLMAP) or depth-camera input for actual 3D reconstruction from photos.
3. Add a 3D viewport with orbit/zoom and dimension annotations.
4. Train/evaluate a dedicated detector on a labeled educational dataset if consistent local/offline recognition is required.
5. Add teacher/student accounts, lessons, quizzes and progress tracking.
6. Add unit selection and mesh repair/validation; never assume STL units.

## Safety and educational note

This is an educational prototype, not a metrology instrument. Verify important measurements against a known reference. AI-generated descriptions can be wrong; encourage students to inspect the geometry and show their reasoning.
